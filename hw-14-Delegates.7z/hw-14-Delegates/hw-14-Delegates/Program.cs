﻿public class CreditCard
{

    public string CardNumber { get; set; }
    public string FullName { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string Pin { get; set; }
    public decimal CreditLimit { get; set; }
    public decimal Balance { get; set; }

    public event Action<decimal> EventDeposit;
    public event Action<decimal> EventWithdraw;
    public event Action EventStartUsingCredit;
    public event Action<decimal> EventReachThreshold;
    public event Action<string> EventPinChanged;

    public CreditCard(string cardNumber, string fullName,
        DateTime expiryDate, string pin, decimal creditLimit,
        decimal initialBalance)
    {
        CardNumber = GenerateCardNumber();
        FullName = fullName;
        ExpiryDate = expiryDate;
        Pin = pin;
        CreditLimit = creditLimit;
        Balance = initialBalance;
    }

    private string GenerateCardNumber()
    {
        Random random = new();
        string[] cardNumberParts = new string[4];

        for (int i = 0; i < 4; i++)
        {
            cardNumberParts[i] = random.Next(1000, 10000).ToString();
        }

        string cardNumber = string.Join("-", cardNumberParts);
        return cardNumber;
    }

    public void Deposit(decimal amount)
    {
        if (amount > 0)
        {
            Balance += amount;
            EventDeposit?.Invoke(amount);
        }
    }

    public bool Withdraw(decimal amount)
    {
        if (amount > 0 && amount <= Balance + CreditLimit)
        {
            Balance -= amount;
            EventWithdraw?.Invoke(amount);
            if (Balance < 0)
            {
                EventStartUsingCredit?.Invoke();
            }
            return true;
        }
        return false;
    }

    public void CheckThreshold(decimal threshold)
    {
        if (Balance <= threshold)
            EventReachThreshold?.Invoke(Balance);
    }

    public void ChangePin(string newPin)
    {
        Pin = newPin;
        EventPinChanged?.Invoke(newPin);
    }
}

public class CreditCardListener
{
    public void Subscribe(CreditCard card)
    {
        card.EventDeposit += HandleDeposit;
        card.EventWithdraw += HandleWithdraw;
        card.EventStartUsingCredit += HandleStartUsingCredit;
        card.EventReachThreshold += HandleReachThreshold;
        card.EventPinChanged += HandlePinChanged;
    }

    private void HandleDeposit(decimal amount)
    {
        Console.WriteLine($"Account replenishment in the amount of: {amount}");
    }
    private void HandleWithdraw(decimal amount)
    {
        Console.WriteLine($"Expenditure from the account in the amount of: {amount}");
    }
    private void HandleStartUsingCredit()
    {
        Console.WriteLine("Use of credit money has begun!");
    }
    private void HandleReachThreshold(decimal balance)
    {
        Console.WriteLine($"Specified amount of money has been reached. Current balance: {balance}");
    }
    private void HandlePinChanged(string newPin)
    {
        Console.WriteLine($"PIN changed to: {newPin}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        CreditCard card = new CreditCard(null, "John Smith Johnson", DateTime.Now.AddYears(5), "6235", 3000, 100);
        CreditCardListener example = new CreditCardListener();
        example.Subscribe(card);

        Console.WriteLine("(Console) Depositing money...");
        card.Deposit(500);

        Console.WriteLine("(Console) Withdrawing money...");
        card.Withdraw(200);

        Console.WriteLine("(Console) Checking threshold...");
        card.CheckThreshold(1000);

        Console.WriteLine("(Console) Withdrawing more money than the available balance...");
        card.Withdraw(500);

        Console.WriteLine("(Console) Changing PIN...");
        card.ChangePin("9876");
    }
}